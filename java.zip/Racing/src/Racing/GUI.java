package Racing;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.Timer;

public class GUI extends JFrame{
	private Image bufferImage;
	private Graphics s_graphic;
	
	private Image menu_screen = new ImageIcon("menu_bg.png").getImage();
	private Image game_screen = new ImageIcon("bgg.gif").getImage();
	private boolean isMenu_Screen, isGame_Screen;
	private Player player = new Player();

	public GUI() {
		setTitle("Racing");
		setSize(Main.WIDTH, Main.HEIGHT);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		setLayout(null);
		init();
	}
	
	private void init() {
		isGame_Screen = false;
		isMenu_Screen = true;
		addKeyListener(new KeyControl());

	}
	
	public void gameStart() {
		isGame_Screen = true;
		isMenu_Screen = false;
		player.start();
	}
	
	public void paint(Graphics g) {
		bufferImage = createImage(Main.WIDTH, Main.HEIGHT);
		s_graphic = bufferImage.getGraphics();
		drawing(s_graphic);
		g.drawImage(bufferImage, 0, 0, null);
		
	}
	public void drawing(Graphics g) {
		if(isGame_Screen) {
			g.drawImage(game_screen, 0, 0, null);
			player.gameDraw(g);
		}
		if(isMenu_Screen) {
			g.drawImage(menu_screen, 0, 0, null);
		}
		this.repaint();
	}
	
	class KeyControl extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			switch(e.getKeyCode()) {
				case KeyEvent.VK_A:
					player.setLeft(true);
					break;
				case KeyEvent.VK_D:
					player.setRight(true);
					break;
				case KeyEvent.VK_ESCAPE:	
					System.exit(0);		//esc누르면 꺼짐
					break;
				
				case KeyEvent.VK_ENTER:	//enter 누르면 게임화면으로
					if(isMenu_Screen) {
						gameStart();
					}
					break;
				case KeyEvent.VK_R:
					if(player.gameOver())
						player.reset();
					break;
			}
		}
		public void keyReleased(KeyEvent e) {
			switch(e.getKeyCode()) {
				case KeyEvent.VK_A:
					player.setLeft(false);
					break;
				case KeyEvent.VK_D:
					player.setRight(false);
					break;
				
			}
		}
		
	}
}

