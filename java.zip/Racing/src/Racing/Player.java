package Racing;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.swing.ImageIcon;

public class Player extends Thread{
	private int delay = 20;
	private long pt;
	private int cnt;
	private int score;
	
	private Image player = new ImageIcon("car2.png").getImage();
	private int playerX, playerY;
	private int playerWidth = player.getWidth(null);
	private int playerHeight = player.getHeight(null);
	private int playerSpeed = 10;
	
	private boolean left, right;
	private boolean gameOver;
	private ArrayList<Comp> compList = new ArrayList<Comp>();
	private Comp comp;
	
	public void run() {
		cnt = 0;
		playerX = 100;
		playerY = 700;
		
		reset();
		while(true) {
			while(!gameOver) {
			pt = System.currentTimeMillis();
			if(System.currentTimeMillis()- pt < delay) {
				try {
					Thread.sleep(delay - System.currentTimeMillis()+pt);
					keyProcess();
					compAppear();
					compMove();
					score++;
					
				} catch(InterruptedException e){
					e.printStackTrace();
				}
				
			}
		}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}
	public void reset() {
		gameOver = false;
		cnt = 0;
		score = 0;
		playerX = 100;
		playerY = 700;
		compList.clear();
	}
		private void keyProcess() {
			if(left && playerX - playerSpeed > 0)
				playerX -= playerSpeed;
			if(right && playerX + playerWidth + playerSpeed < Main.WIDTH)
				playerX += playerSpeed;
		}
		
		private void compAppear() {
			if(cnt % 80 == 0) {
				comp = new Comp(150, (int)(Math.random()*600));
				compList.add(comp);
			}
		}
		
		private void compMove() {
			for (int i = 0; i < compList.size(); i++) {
				comp = compList.get(i);
				comp.move();
			}
		}
		private void crash() {
			for (int i = 0; i < compList.size(); i++) {
				comp = compList.get(i);
				if(playerX > comp.x && playerX < comp.x + comp.width && playerY > comp.y && playerY < comp.y + comp.height) {
					gameOver = true;
				}
			}
		}
		
		public void gameDraw(Graphics g) {
			playerDraw(g);
			compDraw(g);
			sc_Draw(g);
		}
		
		public void sc_Draw(Graphics g) {
			g.setColor(Color.BLACK);
			g.setFont(new Font("Arial", Font.BOLD, 20));
			g.drawString("Score : " + score, 40, 80);
			if(gameOver) {
				g.setColor(Color.BLACK);
				g.setFont(new Font("Arial", Font.BOLD, 80));
				g.drawString("Press R to restart", 210, 550);
			}
		}
		
		public void playerDraw(Graphics g) {
			g.drawImage(player, playerX, playerY, null);
			
		}
		
		public void compDraw(Graphics g) {
			for (int i = 0; i < compList.size(); i++) {
				comp = compList.get(i);
				g.drawImage(comp.image, comp.x, comp.y, null);
			}
		}
		public boolean gameOver() {
			return gameOver;
		}
		
		public void setLeft(boolean left) {
			this.left = left;
		}
		
		public void setRight(boolean right) {
			this.right = right;
		}

	}

