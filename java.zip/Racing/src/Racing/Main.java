package Racing;

public class Main {
	public static final int WIDTH = 500;
	public static final int HEIGHT = 800;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GUI();
	}
}
