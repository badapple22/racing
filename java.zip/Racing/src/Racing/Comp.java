package Racing;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Comp {
	Image image = new ImageIcon("car1.png").getImage();
	int x, y;
	int width = image.getWidth(null);
	int height = image.getHeight(null);
	
	public Comp(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void move() {
		this.y += 3;
	}
}
