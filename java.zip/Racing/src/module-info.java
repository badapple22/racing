/**
 * 
 */
/**
 * @author badap
 *
 */
module Racing {
	requires java.desktop;
}